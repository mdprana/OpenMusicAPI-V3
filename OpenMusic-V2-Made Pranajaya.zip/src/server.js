require('dotenv').config();

const Hapi = require('@hapi/hapi');
const Jwt = require('@hapi/jwt');

// Import semua routes
const albums = require('./routes/albums');
const songs = require('./routes/songs');
const users = require('./routes/users');
const authentications = require('./routes/authentications');
const playlists = require('./routes/playlists');

// Import error classes
const ClientError = require('./exceptions/ClientError');

const init = async () => {
  const server = Hapi.server({
    port: process.env.PORT || 5000,
    host: process.env.HOST || 'localhost',
    routes: {
      cors: {
        origin: ['*'],
      },
    },
  });

  // Register JWT plugin
  await server.register([
    {
      plugin: Jwt,
    },
  ]);

  // Define JWT authentication strategy
  server.auth.strategy('openmusic_jwt', 'jwt', {
    keys: process.env.ACCESS_TOKEN_KEY,
    verify: {
      aud: false,
      iss: false,
      sub: false,
      maxAgeSec: process.env.ACCESS_TOKEN_AGE,
    },
    validate: (artifacts) => ({
      isValid: true,
      credentials: {
        id: artifacts.decoded.payload.id,
      },
    }),
  });

  // CRITICAL: Global error handling dengan onPreResponse
  server.ext('onPreResponse', (request, h) => {
    const { response } = request;

    if (response instanceof Error) {
      // Handle Joi validation errors (dari route validation)
      if (response.isJoi || response.name === 'ValidationError') {
        const newResponse = h.response({
          status: 'fail',
          message: response.details ? response.details[0].message : response.message,
        });
        newResponse.code(400);
        return newResponse;
      }

      // Handle custom client errors (InvariantError, NotFoundError, etc.)
      if (response instanceof ClientError) {
        const newResponse = h.response({
          status: 'fail',
          message: response.message,
        });
        newResponse.code(response.statusCode);
        return newResponse;
      }

      // Handle Hapi boom errors (404, etc.)
      if (response.isBoom) {
        const { statusCode } = response.output;
        
        if (statusCode === 404) {
          const newResponse = h.response({
            status: 'fail',
            message: 'Resource tidak ditemukan',
          });
          newResponse.code(404);
          return newResponse;
        }

        if (statusCode >= 400 && statusCode < 500) {
          const newResponse = h.response({
            status: 'fail',
            message: response.message || response.output.payload.message,
          });
          newResponse.code(statusCode);
          return newResponse;
        }

        // Server errors (500+)
        const newResponse = h.response({
          status: 'error',
          message: 'Maaf, terjadi kegagalan pada server kami.',
        });
        newResponse.code(500);
        console.error(response);
        return newResponse;
      }

      // Generic server errors
      const newResponse = h.response({
        status: 'error',
        message: 'Maaf, terjadi kegagalan pada server kami.',
      });
      newResponse.code(500);
      console.error(response);
      return newResponse;
    }

    // Continue with normal response
    return h.continue;
  });

  // Register semua routes
  server.route([
    ...albums,
    ...songs,
    ...users,
    ...authentications,
    ...playlists,
  ]);

  // Register optional routes jika tersedia
  try {
    const collaborations = require('./routes/collaborations');
    server.route(collaborations);
    console.log('✓ Collaborations feature enabled');
  } catch (error) {
    console.log('○ Collaborations feature not implemented');
  }

  await server.start();
  console.log(`Server berjalan pada ${server.info.uri}`);
};

// Handle unhandled promise rejections
process.on('unhandledRejection', (err) => {
  console.log('Unhandled Rejection:', err);
  process.exit(1);
});

init();